#include <stdio.h>
#include <stdlib.h>
#include "k_tree.h"

#define DATA_LINE_MAX_CHARS    4096
#define DATA_DATATYPE_STRING      1

#define DATA_TABLE_MAX_LINE    1000000

struct table_info{
    int column_num;
    int row_num;
    int row_pos;
    struct table_array_info **p_rows;    /* ��ָ�� */
    void *p_column_labels;
};

struct table_array_info{
    int item_num;       /* array(��)���������������� */
    int item_pos;       /* array(��)�е�ǰ������λ�� */ 
    struct table_item_info **p_items;      /* array ����ָ�� */
    void *p_tail;
};

struct table_item_info{
    int data_type;    /* �������� */
    void *p_data;
    int data_size;    /* ���ݴ�С */
};

int data_read_csv_to_table_info(struct table_info **p_table, FILE *fp_csv, char sep);
int data_array_roomid_cmp(void *a1, void *a2);
int data_table_distinct_count(struct k_tree *array);

int count;

int main()
{
    int i;
    char *csv = "2015092212-2015092214.csv";
    FILE *fp_csv = fopen(csv, "rb");
    struct table_info *table;
    struct table_info *table_387, *table_525, *table_165;
    struct k_tree *tree_525, *tree_387, *tree_165;
    struct k_tree *find_387, *find_165, *find_525;
    struct table_array_info *row_now;
    int diff_count;
    
    freopen("log.txt", "wb", stdout);
    
    printf("file: %s\n", csv);
    
    tree_525 = tree_387 = tree_165 = NULL;
    
    data_read_csv_to_table_info(&table, fp_csv, ',');
    
    //data_print_table(table, "all");

//    data_table_new(&table_temp, DATA_TABLE_MAX_LINE);
//    data_table_add_row(table_temp, table -> p_rows[0]);
//    data_print_table(table_temp);
    data_table_select_387(table, &table_387);
    data_table_select_525(table, &table_525);
    data_table_select_165(table, &table_165);
    
    printf("rows of 525 is %d\n", data_table_get_rows(table_525));
    printf("rows of 387 is %d\n", data_table_get_rows(table_387));
    printf("rows of 165 is %d\n", data_table_get_rows(table_165));

    data_table_insert_to_tree(table_387, &tree_387, data_array_roomid_cmp);
    data_table_insert_to_tree(table_525, &tree_525, data_array_roomid_cmp);
    data_table_insert_to_tree(table_165, &tree_165, data_array_roomid_cmp);

    count = 0;
    k_tree_ergodic(tree_525, data_table_distinct_count);
    printf("525 distinct roomid = %d\n", count);
    count = 0;
    k_tree_ergodic(tree_165, data_table_distinct_count);
    printf("165 distinct roomid = %d\n", count);
    count = 0;
    k_tree_ergodic(tree_387, data_table_distinct_count);
    printf("387 distinct roomid = %d\n", count);

    diff_count = 0;
    printf("====  start  525 �� 165 ���еģ����� dc00387 û�е� ====\n");
    for(i = 0; i < table_525 -> row_pos; i ++){
        row_now = table_525 -> p_rows[i];
        find_387 = k_tree_search(tree_387, row_now, data_array_roomid_cmp);
        find_165 = k_tree_search(tree_165, row_now, data_array_roomid_cmp);
        if(find_387 == NULL && find_165 != NULL){
            printf("%4d:: roomid=%s, uin= %s, to_uin= %s\n", diff_count, row_now -> p_items[2] -> p_data, 
                ((struct table_array_info *)find_165 -> p_data) -> p_items[0] -> p_data, ((struct table_array_info *)find_165 -> p_data) -> p_items[1] -> p_data);
            diff_count ++;
            //getchar();
        }
    }
    printf("==== end    525 �� 165 ���еģ����� dc00387 û�е� ====\n");
    
    
    diff_count = 0;
    printf("====  start  525 �� 165 ��û�еģ����� dc00387 �е� ====\n");
    for(i = 0; i < table_387 -> row_pos; i ++){
        row_now = table_387 -> p_rows[i];
        find_165 = k_tree_search(tree_165, row_now, data_array_roomid_cmp);
        find_525 = k_tree_search(tree_165, row_now, data_array_roomid_cmp);
        if(find_525 == NULL && find_165 == NULL){
            printf("%4d:: roomid=%s\n", diff_count, row_now -> p_items[2] -> p_data);
            diff_count ++;
            //getchar();
        }
    }
    printf("==== end    525 �� 165 ��û�еģ����� dc00387 �е� ====\n");

    getchar();
}

int data_array_roomid_cmp(void *a1, void *a2)
{
    struct table_array_info *array_1, *array_2;
    char *a, *b;
    
    array_1 = (struct table_array_info *)a1;
    array_2 = (struct table_array_info *)a2;
    a = (char *)array_1 -> p_items[2] -> p_data;
    b = (char *)array_2 -> p_items[2] -> p_data;
    
    return strcmp(a, b);
}

int data_table_distinct_count(struct k_tree *array)
{
    count ++;
}

int data_table_select_387(struct table_info *table, struct table_info **result)
{
    int i;
    struct table_array_info *row_now;
    struct table_info *t;
    
    data_table_new(result, DATA_TABLE_MAX_LINE);
    t = *result;
    //printf("select:row_pos = %d\n", t -> row_pos);
    
    for(i = 0; i < table -> row_pos; i ++){
        row_now = table -> p_rows[i];
        if(strcmp(row_now -> p_items[3] -> p_data, "00387") == 0){
            //printf("select:row_pos = %d\n", t -> row_pos);
            data_table_add_row(t, row_now);
        }
    }
    return 0;
}

int data_table_select_525(struct table_info *table, struct table_info **result)
{
    int i;
    struct table_array_info *row_now;
    struct table_info *t;
    
    data_table_new(result, DATA_TABLE_MAX_LINE);
    t = *result;
    
    for(i = 0; i < table -> row_pos; i ++){
        row_now = table -> p_rows[i];
        if(strcmp(row_now -> p_items[3] -> p_data, "525") == 0){
            //printf("select:row_pos = %d\n", t -> row_pos);
            data_table_add_row(t, row_now);
        }
    }
    return 0;
}

int data_table_select_165(struct table_info *table, struct table_info **result)
{
    int i;
    struct table_array_info *row_now;
    struct table_info *t;
    
    data_table_new(result, DATA_TABLE_MAX_LINE);
    t = *result;
    
    for(i = 0; i < table -> row_pos; i ++){
        row_now = table -> p_rows[i];
        if(strcmp(row_now -> p_items[3] -> p_data, "165") == 0){
            //printf("select:row_pos = %d\n", t -> row_pos);
            data_table_add_row(t, row_now);
        }
    }
    return 0;
}

int data_table_insert_to_tree(struct table_info *table, struct k_tree **root, int cmp(void *a1, void *a2))
{
    int i;
    
    for(i = 0; i < table -> row_pos; i ++){
        k_tree_insert_item_to_tree(root, table -> p_rows[i], cmp);
    }
    
    return 0;
}

int data_table_get_rows(struct table_info *table)
{
    return table -> row_pos;
}

int data_table_new(struct table_info **table, int row_num)
{
    *table = (struct table_info *)malloc(sizeof(struct table_info));
    (*table) -> row_num = row_num;
    (*table) -> p_rows = (struct table_array_info **)malloc(sizeof(struct table_array_info *) * DATA_TABLE_MAX_LINE);
    (*table) -> row_pos = 0;
    
    return 0;
}

int data_table_add_row(struct table_info *table, struct table_array_info *array)
{
    //printf("row_pos = %d\n", table -> row_pos);
    data_table_copy_row(&table -> p_rows[table -> row_pos], array);
    table -> row_pos ++;
    
    return 0;
}

int data_table_copy_row(struct table_array_info **array_dest, struct table_array_info *array_src)
{
    int i;
    struct table_array_info *dest;
    
    *array_dest = (struct table_array_info *)malloc(sizeof(struct table_array_info));
    dest = *array_dest;
    
    dest -> item_num = array_src -> item_num;
    dest -> item_pos = array_src -> item_pos;
    dest -> p_items = (struct table_item_info **)malloc(sizeof(struct table_item_info *) * dest -> item_num);
    
    for(i = 0; i < dest -> item_pos; i++){
        data_table_copy_item(&dest -> p_items[i], array_src -> p_items[i]);
    }
    
    return 0;
}

int data_table_copy_item(struct table_item_info **item_dest, struct table_item_info *item_src)
{
    struct table_item_info *dest;
    
    *item_dest = (struct table_item_info *)malloc(sizeof(struct table_item_info));
    dest = *item_dest;
    
    dest -> data_type = item_src -> data_type;
    dest -> data_size = item_src -> data_size;
    dest -> p_data = (void *)malloc(dest -> data_size + 1);    /* Ĭ�϶�����1�ֽڷ�'\0' */
    memcpy(dest -> p_data, item_src -> p_data, dest -> data_size);
    ((char *)dest -> p_data)[dest -> data_size] = '\0';
    
    return 0;
}

int data_split_line(struct table_array_info *array, char *line, char sep)
{
    int i, count, pos_start, pos_end, pos_now, size;
    int item_pos;
    int c;
    struct table_item_info *item;
    
    for(i = 0, count = 0; line[i] != '\0'; i ++){
        if(line[i] == sep){
            count ++;
        }
    }
    if(count > 0)
        count ++;
    
    array -> item_num = count;
    array -> p_items = (struct table_item_info **)malloc(sizeof(struct table_item_info *) * count);
    array -> p_tail = NULL;
    
    array -> item_pos = 0;
    pos_now = pos_start = 0;
    pos_end = strlen(line);
    
    for(i = pos_end - 1; i >= 0; i --){
        if(line[i] == '\n' || line[i] == '\r' || line[i] == ' '){
            pos_end --;
            line[i] = '\0';
        }else{
            break;
        }
    }
    
    item_pos = 0;
    while(1){
        c = line[pos_now];
        if(c == '\0' || c == sep){
            pos_end = pos_now - 1;
            size = pos_end - pos_start + 1;
            item = (struct table_item_info *)malloc(sizeof(struct table_item_info));
            item -> data_type = DATA_DATATYPE_STRING;
            item -> p_data = (void *)malloc(size + 1);    /* Ĭ�϶�����1�ֽڷ�'\0' */
            item -> data_size = size;
            memcpy(item -> p_data, line+pos_start, pos_end - pos_start + 1);
            ((char *)item -> p_data)[size] = '\0';
            
            array -> p_items[item_pos] = item;
            
            item_pos ++;
            array -> item_pos ++; 
            pos_now ++;
            
            while(line[pos_now] == '\r' || line[pos_now] == '\n' || line[pos_now] == ' '){
                pos_now ++;
            }
            pos_start = pos_now;
        }else{
            pos_now ++;
        }
        if(c == '\0')
            break;
    }
    
    return 0;
}

int data_print_array(struct table_array_info *array)
{
    int i;
    
    for(i = 0; i < array -> item_pos; i ++){
        printf("%s | ", array -> p_items[i] -> p_data);
    }
    
    printf("\n");
    
    return 0;
}

int data_print_table(struct table_info *table, char *table_name)
{
    int i, num;
    if(table -> row_pos > 1000)
         num = 1000;
    else
         num = table -> row_pos;
    
    printf("\n--------------- table[%s] start -----------------\n", table_name);
    for(i = 0; i < num; i ++){
        printf("#%4d:", i);
        data_print_array(table -> p_rows[i]);
    }
    printf("--------------- table[%s] end   -----------------\n", table_name);
    return 0;
}



int data_read_csv_to_table_info(struct table_info **p_table, FILE *fp_csv, char sep)
{
    char buf[DATA_LINE_MAX_CHARS];
    struct table_array_info array;
    struct table_info *table;
    
    data_table_new(&table, DATA_TABLE_MAX_LINE);

    while(1){
        if(fgets(buf, DATA_LINE_MAX_CHARS, fp_csv) == NULL)
            break;
        else{
            //printf("%s", buf);
            table -> p_rows[table -> row_pos] = (struct table_array_info *)malloc(sizeof(struct table_array_info));
            data_split_line(table -> p_rows[table -> row_pos], buf, sep);
            //data_print_array(table -> p_rows[table -> row_pos]);
            table -> row_pos ++;
            //system("pause");
        }
    }
    
    *p_table = table;
    return 0;
}
