# 1 "E:\\code\\DataBase\\k_data.c"
# 1 "E:\\code\\DataBase//"
# 1 "<built-in>"
#define __STDC_HOSTED__ 1
#define __GNUC__ 3
#define __GNUC_MINOR__ 4
#define __GNUC_PATCHLEVEL__ 2
#define __SIZE_TYPE__ unsigned int
#define __PTRDIFF_TYPE__ int
#define __WCHAR_TYPE__ short unsigned int
#define __WINT_TYPE__ short unsigned int
#define __GXX_ABI_VERSION 1002
#define __USING_SJLJ_EXCEPTIONS__ 1
#define __SCHAR_MAX__ 127
#define __SHRT_MAX__ 32767
#define __INT_MAX__ 2147483647
#define __LONG_MAX__ 2147483647L
#define __LONG_LONG_MAX__ 9223372036854775807LL
#define __WCHAR_MAX__ 65535U
#define __CHAR_BIT__ 8
#define __FLT_EVAL_METHOD__ 2
#define __FLT_RADIX__ 2
#define __FLT_MANT_DIG__ 24
#define __FLT_DIG__ 6
#define __FLT_MIN_EXP__ (-125)
#define __FLT_MIN_10_EXP__ (-37)
#define __FLT_MAX_EXP__ 128
#define __FLT_MAX_10_EXP__ 38
#define __FLT_MAX__ 3.40282347e+38F
#define __FLT_MIN__ 1.17549435e-38F
#define __FLT_EPSILON__ 1.19209290e-7F
#define __FLT_DENORM_MIN__ 1.40129846e-45F
#define __FLT_HAS_INFINITY__ 1
#define __FLT_HAS_QUIET_NAN__ 1
#define __DBL_MANT_DIG__ 53
#define __DBL_DIG__ 15
#define __DBL_MIN_EXP__ (-1021)
#define __DBL_MIN_10_EXP__ (-307)
#define __DBL_MAX_EXP__ 1024
#define __DBL_MAX_10_EXP__ 308
#define __DBL_MAX__ 1.7976931348623157e+308
#define __DBL_MIN__ 2.2250738585072014e-308
#define __DBL_EPSILON__ 2.2204460492503131e-16
#define __DBL_DENORM_MIN__ 4.9406564584124654e-324
#define __DBL_HAS_INFINITY__ 1
#define __DBL_HAS_QUIET_NAN__ 1
#define __LDBL_MANT_DIG__ 64
#define __LDBL_DIG__ 18
#define __LDBL_MIN_EXP__ (-16381)
#define __LDBL_MIN_10_EXP__ (-4931)
#define __LDBL_MAX_EXP__ 16384
#define __LDBL_MAX_10_EXP__ 4932
#define __DECIMAL_DIG__ 21
#define __LDBL_MAX__ 1.18973149535723176502e+4932L
#define __LDBL_MIN__ 3.36210314311209350626e-4932L
#define __LDBL_EPSILON__ 1.08420217248550443401e-19L
#define __LDBL_DENORM_MIN__ 3.64519953188247460253e-4951L
#define __LDBL_HAS_INFINITY__ 1
#define __LDBL_HAS_QUIET_NAN__ 1
#define __REGISTER_PREFIX__ 
#define __USER_LABEL_PREFIX__ _
#define __VERSION__ "3.4.2 (mingw-special)"
#define __NO_INLINE__ 1
#define __FINITE_MATH_ONLY__ 0


#define __i386 1
#define __i386__ 1
#define i386 1
#define __tune_i686__ 1
#define __tune_pentiumpro__ 1
#define _X86_ 1

#define __stdcall __attribute__((__stdcall__))
#define __fastcall __attribute__((__fastcall__))
#define __cdecl __attribute__((__cdecl__))
#define __declspec(x) __attribute__((x))
#define _stdcall __attribute__((__stdcall__))
#define _fastcall __attribute__((__fastcall__))
#define _cdecl __attribute__((__cdecl__))
#define __MSVCRT__ 1
#define __MINGW32__ 1
#define _WIN32 1
#define __WIN32 1
#define __WIN32__ 1
#define WIN32 1
#define __WINNT 1
#define __WINNT__ 1
#define WINNT 1
# 1 "<command line>"
# 1 "E:\\code\\DataBase\\k_data.c"
# 1 "E:\\code\\DataBase\\/k_data.h" 1
# 12 "E:\\code\\DataBase\\/k_data.h"
#define __K_DATA_H__ 

# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 1 3
# 16 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 3
#define _STDIO_H_ 


# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/_mingw.h" 1 3
# 24 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/_mingw.h" 3
#define __MINGW_H 
# 48 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/_mingw.h" 3
#undef __attribute__
# 64 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/_mingw.h" 3
#define __MINGW_IMPORT extern __attribute__ ((dllimport))





#define _CRTIMP 


#define __DECLSPEC_SUPPORTED 
# 88 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/_mingw.h" 3
#define __int64 long long


#define __int32 long


#define __int16 short


#define __int8 char


#define __small char


#define __hyper long long






#define __CRT_INLINE extern __inline__






#define __UNUSED_PARAM(x) x __attribute__ ((__unused__))






#define __MINGW_ATTRIB_NORETURN __attribute__ ((__noreturn__))
#define __MINGW_ATTRIB_CONST __attribute__ ((__const__))






#define __MINGW_ATTRIB_MALLOC __attribute__ ((__malloc__))
#define __MINGW_ATTRIB_PURE __attribute__ ((__pure__))







#define __MSVCRT_VERSION__ 0x0600


#define __MINGW32_VERSION 3.7
#define __MINGW32_MAJOR_VERSION 3
#define __MINGW32_MINOR_VERSION 7
# 20 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 2 3


#define __need_size_t 
#define __need_NULL 
#define __need_wchar_t 
#define __need_wint_t 
# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stddef.h" 1 3





# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 1 3 4
# 188 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#define __size_t__ 
#define __SIZE_T__ 
#define _SIZE_T 
#define _SYS_SIZE_T_H 
#define _T_SIZE_ 
#define _T_SIZE 
#define __SIZE_T 
#define _SIZE_T_ 
#define _BSD_SIZE_T_ 
#define _SIZE_T_DEFINED_ 
#define _SIZE_T_DEFINED 
#define _BSD_SIZE_T_DEFINED_ 
#define _SIZE_T_DECLARED 
#define ___int_size_t_h 
#define _GCC_SIZE_T 
#define _SIZET_ 



#define __size_t 





typedef unsigned int size_t;
# 235 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_size_t
# 264 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#define __wchar_t__ 
#define __WCHAR_T__ 
#define _WCHAR_T 
#define _T_WCHAR_ 
#define _T_WCHAR 
#define __WCHAR_T 
#define _WCHAR_T_ 
#define _BSD_WCHAR_T_ 
#define _WCHAR_T_DEFINED_ 
#define _WCHAR_T_DEFINED 
#define _WCHAR_T_H 
#define ___int_wchar_t_h 
#define __INT_WCHAR_T_H 
#define _GCC_WCHAR_T 
#define _WCHAR_T_DECLARED 
# 291 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef _BSD_WCHAR_T_
# 325 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
typedef short unsigned int wchar_t;
# 344 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_wchar_t




#define _WINT_T 




typedef short unsigned int wint_t;

#undef __need_wint_t
# 397 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef NULL




#define NULL ((void *)0)





#undef __need_NULL
# 7 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stddef.h" 2 3
# 27 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 2 3
#define __need___va_list 
# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdarg.h" 1 3





# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stdarg.h" 1 3 4
# 38 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stdarg.h" 3 4
#undef __need___va_list




#define __GNUC_VA_LIST 
typedef __builtin_va_list __gnuc_va_list;
# 7 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdarg.h" 2 3
# 29 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 2 3




#define _IOREAD 1
#define _IOWRT 2
#define _IORW 0x0080






#define STDIN_FILENO 0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2


#define EOF (-1)







#define FILENAME_MAX (260)






#define FOPEN_MAX (20)


#define TMP_MAX 32767






#define _P_tmpdir "\\"

#define P_tmpdir _P_tmpdir

#define _wP_tmpdir L"\\"







#define L_tmpnam (16)

#define _IOFBF 0x0000
#define _IOLBF 0x0040
#define _IONBF 0x0004

#define _IOMYBUF 0x0008
#define _IOEOF 0x0010
#define _IOERR 0x0020
#define _IOSTRG 0x0040







#define BUFSIZ 512





#define SEEK_SET (0)



#define SEEK_CUR (1)



#define SEEK_END (2)







#define __VALIST __gnuc_va_list
# 137 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 3
#define _FILE_DEFINED 
typedef struct _iobuf
{
 char* _ptr;
 int _cnt;
 char* _base;
 int _flag;
 int _file;
 int _charbuf;
 int _bufsiz;
 char* _tmpfname;
} FILE;
# 163 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 3
extern __attribute__ ((dllimport)) FILE _iob[];



#define stdin (&_iob[STDIN_FILENO])
#define stdout (&_iob[STDOUT_FILENO])
#define stderr (&_iob[STDERR_FILENO])
# 178 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 3
 FILE* __attribute__((__cdecl__)) fopen (const char*, const char*);
 FILE* __attribute__((__cdecl__)) freopen (const char*, const char*, FILE*);
 int __attribute__((__cdecl__)) fflush (FILE*);
 int __attribute__((__cdecl__)) fclose (FILE*);

 int __attribute__((__cdecl__)) remove (const char*);
 int __attribute__((__cdecl__)) rename (const char*, const char*);
 FILE* __attribute__((__cdecl__)) tmpfile (void);
 char* __attribute__((__cdecl__)) tmpnam (char*);


 char* __attribute__((__cdecl__)) _tempnam (const char*, const char*);
 int __attribute__((__cdecl__)) _rmtmp(void);


 char* __attribute__((__cdecl__)) tempnam (const char*, const char*);
 int __attribute__((__cdecl__)) rmtmp(void);



 int __attribute__((__cdecl__)) setvbuf (FILE*, char*, int, size_t);

 void __attribute__((__cdecl__)) setbuf (FILE*, char*);





 int __attribute__((__cdecl__)) fprintf (FILE*, const char*, ...);
 int __attribute__((__cdecl__)) printf (const char*, ...);
 int __attribute__((__cdecl__)) sprintf (char*, const char*, ...);
 int __attribute__((__cdecl__)) _snprintf (char*, size_t, const char*, ...);
 int __attribute__((__cdecl__)) vfprintf (FILE*, const char*, __gnuc_va_list);
 int __attribute__((__cdecl__)) vprintf (const char*, __gnuc_va_list);
 int __attribute__((__cdecl__)) vsprintf (char*, const char*, __gnuc_va_list);
 int __attribute__((__cdecl__)) _vsnprintf (char*, size_t, const char*, __gnuc_va_list);


int __attribute__((__cdecl__)) snprintf(char* s, size_t n, const char* format, ...);
extern __inline__ int __attribute__((__cdecl__))
vsnprintf (char* s, size_t n, const char* format, __gnuc_va_list arg)
  { return _vsnprintf ( s, n, format, arg); }
int __attribute__((__cdecl__)) vscanf (const char * __restrict__, __gnuc_va_list);
int __attribute__((__cdecl__)) vfscanf (FILE * __restrict__, const char * __restrict__,
       __gnuc_va_list);
int __attribute__((__cdecl__)) vsscanf (const char * __restrict__,
       const char * __restrict__, __gnuc_va_list);






 int __attribute__((__cdecl__)) fscanf (FILE*, const char*, ...);
 int __attribute__((__cdecl__)) scanf (const char*, ...);
 int __attribute__((__cdecl__)) sscanf (const char*, const char*, ...);




 int __attribute__((__cdecl__)) fgetc (FILE*);
 char* __attribute__((__cdecl__)) fgets (char*, int, FILE*);
 int __attribute__((__cdecl__)) fputc (int, FILE*);
 int __attribute__((__cdecl__)) fputs (const char*, FILE*);
 char* __attribute__((__cdecl__)) gets (char*);
 int __attribute__((__cdecl__)) puts (const char*);
 int __attribute__((__cdecl__)) ungetc (int, FILE*);







 int __attribute__((__cdecl__)) _filbuf (FILE*);
 int __attribute__((__cdecl__)) _flsbuf (int, FILE*);



extern __inline__ int __attribute__((__cdecl__)) getc (FILE* __F)
{
  return (--__F->_cnt >= 0)
    ? (int) (unsigned char) *__F->_ptr++
    : _filbuf (__F);
}

extern __inline__ int __attribute__((__cdecl__)) putc (int __c, FILE* __F)
{
  return (--__F->_cnt >= 0)
    ? (int) (unsigned char) (*__F->_ptr++ = (char)__c)
    : _flsbuf (__c, __F);
}

extern __inline__ int __attribute__((__cdecl__)) getchar (void)
{
  return (--(&_iob[0])->_cnt >= 0)
    ? (int) (unsigned char) *(&_iob[0])->_ptr++
    : _filbuf ((&_iob[0]));
}

extern __inline__ int __attribute__((__cdecl__)) putchar(int __c)
{
  return (--(&_iob[1])->_cnt >= 0)
    ? (int) (unsigned char) (*(&_iob[1])->_ptr++ = (char)__c)
    : _flsbuf (__c, (&_iob[1]));}
# 297 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 3
 size_t __attribute__((__cdecl__)) fread (void*, size_t, size_t, FILE*);
 size_t __attribute__((__cdecl__)) fwrite (const void*, size_t, size_t, FILE*);





 int __attribute__((__cdecl__)) fseek (FILE*, long, int);
 long __attribute__((__cdecl__)) ftell (FILE*);
 void __attribute__((__cdecl__)) rewind (FILE*);
# 330 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 3
typedef long long fpos_t;




 int __attribute__((__cdecl__)) fgetpos (FILE*, fpos_t*);
 int __attribute__((__cdecl__)) fsetpos (FILE*, const fpos_t*);





 int __attribute__((__cdecl__)) feof (FILE*);
 int __attribute__((__cdecl__)) ferror (FILE*);







#define feof(__F) ((__F)->_flag & _IOEOF)
#define ferror(__F) ((__F)->_flag & _IOERR)


 void __attribute__((__cdecl__)) clearerr (FILE*);
 void __attribute__((__cdecl__)) perror (const char*);






 FILE* __attribute__((__cdecl__)) _popen (const char*, const char*);
 int __attribute__((__cdecl__)) _pclose (FILE*);


 FILE* __attribute__((__cdecl__)) popen (const char*, const char*);
 int __attribute__((__cdecl__)) pclose (FILE*);





 int __attribute__((__cdecl__)) _flushall (void);
 int __attribute__((__cdecl__)) _fgetchar (void);
 int __attribute__((__cdecl__)) _fputchar (int);
 FILE* __attribute__((__cdecl__)) _fdopen (int, const char*);
 int __attribute__((__cdecl__)) _fileno (FILE*);
 int __attribute__((__cdecl__)) _fcloseall(void);
 FILE* __attribute__((__cdecl__)) _fsopen(const char*, const char*, int);

 int __attribute__((__cdecl__)) _getmaxstdio(void);
 int __attribute__((__cdecl__)) _setmaxstdio(int);



 int __attribute__((__cdecl__)) fgetchar (void);
 int __attribute__((__cdecl__)) fputchar (int);
 FILE* __attribute__((__cdecl__)) fdopen (int, const char*);
 int __attribute__((__cdecl__)) fileno (FILE*);


#define _fileno(__F) ((__F)->_file)

#define fileno(__F) ((__F)->_file)



# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/sys/types.h" 1 3
# 12 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/sys/types.h" 3
#define _TYPES_H_ 




#define __need_wchar_t 
#define __need_size_t 
#define __need_ptrdiff_t 

# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stddef.h" 1 3





# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 1 3 4
# 140 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#define _PTRDIFF_T 
#define _T_PTRDIFF_ 
#define _T_PTRDIFF 
#define __PTRDIFF_T 
#define _PTRDIFF_T_ 
#define _BSD_PTRDIFF_T_ 
#define ___int_ptrdiff_t_h 
#define _GCC_PTRDIFF_T 



typedef int ptrdiff_t;
# 162 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_ptrdiff_t
# 235 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_size_t
# 344 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_wchar_t
# 408 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_NULL
# 7 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stddef.h" 2 3
# 22 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/sys/types.h" 2 3





typedef long time_t;
#define _TIME_T_DEFINED 



typedef long long __time64_t;
#define _TIME64_T_DEFINED 



#define _OFF_T_ 
typedef long _off_t;


typedef _off_t off_t;





#define _DEV_T_ 

typedef unsigned int _dev_t;





typedef _dev_t dev_t;





#define _INO_T_ 
typedef short _ino_t;


typedef _ino_t ino_t;





#define _PID_T_ 
typedef int _pid_t;


typedef _pid_t pid_t;





#define _MODE_T_ 
typedef unsigned short _mode_t;


typedef _mode_t mode_t;





#define _SIGSET_T_ 
typedef int _sigset_t;


typedef _sigset_t sigset_t;




#define _SSIZE_T_ 
typedef long _ssize_t;


typedef _ssize_t ssize_t;




#define _FPOS64_T_ 
typedef long long fpos64_t;



#define _OFF64_T_ 
typedef long long off64_t;
# 400 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 2 3
extern __inline__ FILE* __attribute__((__cdecl__)) fopen64 (const char* filename, const char* mode)
{
  return fopen (filename, mode);
}

int __attribute__((__cdecl__)) fseeko64 (FILE*, off64_t, int);






extern __inline__ off64_t __attribute__((__cdecl__)) ftello64 (FILE * stream)
{
  fpos_t pos;
  if (fgetpos(stream, &pos))
    return -1LL;
  else
   return ((off64_t) pos);
}
# 428 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdio.h" 3
 int __attribute__((__cdecl__)) fwprintf (FILE*, const wchar_t*, ...);
 int __attribute__((__cdecl__)) wprintf (const wchar_t*, ...);
 int __attribute__((__cdecl__)) swprintf (wchar_t*, const wchar_t*, ...);
 int __attribute__((__cdecl__)) _snwprintf (wchar_t*, size_t, const wchar_t*, ...);
 int __attribute__((__cdecl__)) vfwprintf (FILE*, const wchar_t*, __gnuc_va_list);
 int __attribute__((__cdecl__)) vwprintf (const wchar_t*, __gnuc_va_list);
 int __attribute__((__cdecl__)) vswprintf (wchar_t*, const wchar_t*, __gnuc_va_list);
 int __attribute__((__cdecl__)) _vsnwprintf (wchar_t*, size_t, const wchar_t*, __gnuc_va_list);
 int __attribute__((__cdecl__)) fwscanf (FILE*, const wchar_t*, ...);
 int __attribute__((__cdecl__)) wscanf (const wchar_t*, ...);
 int __attribute__((__cdecl__)) swscanf (const wchar_t*, const wchar_t*, ...);
 wint_t __attribute__((__cdecl__)) fgetwc (FILE*);
 wint_t __attribute__((__cdecl__)) fputwc (wchar_t, FILE*);
 wint_t __attribute__((__cdecl__)) ungetwc (wchar_t, FILE*);


 wchar_t* __attribute__((__cdecl__)) fgetws (wchar_t*, int, FILE*);
 int __attribute__((__cdecl__)) fputws (const wchar_t*, FILE*);
 wint_t __attribute__((__cdecl__)) getwc (FILE*);
 wint_t __attribute__((__cdecl__)) getwchar (void);
 wchar_t* __attribute__((__cdecl__)) _getws (wchar_t*);
 wint_t __attribute__((__cdecl__)) putwc (wint_t, FILE*);
 int __attribute__((__cdecl__)) _putws (const wchar_t*);
 wint_t __attribute__((__cdecl__)) putwchar (wint_t);
 FILE* __attribute__((__cdecl__)) _wfdopen(int, wchar_t *);
 FILE* __attribute__((__cdecl__)) _wfopen (const wchar_t*, const wchar_t*);
 FILE* __attribute__((__cdecl__)) _wfreopen (const wchar_t*, const wchar_t*, FILE*);
 FILE* __attribute__((__cdecl__)) _wfsopen (const wchar_t*, const wchar_t*, int);
 wchar_t* __attribute__((__cdecl__)) _wtmpnam (wchar_t*);
 wchar_t* __attribute__((__cdecl__)) _wtempnam (const wchar_t*, const wchar_t*);
 int __attribute__((__cdecl__)) _wrename (const wchar_t*, const wchar_t*);
 int __attribute__((__cdecl__)) _wremove (const wchar_t*);
 void __attribute__((__cdecl__)) _wperror (const wchar_t*);
 FILE* __attribute__((__cdecl__)) _wpopen (const wchar_t*, const wchar_t*);



int __attribute__((__cdecl__)) snwprintf (wchar_t* s, size_t n, const wchar_t* format, ...);
extern __inline__ int __attribute__((__cdecl__))
vsnwprintf (wchar_t* s, size_t n, const wchar_t* format, __gnuc_va_list arg)
  { return _vsnwprintf ( s, n, format, arg);}
int __attribute__((__cdecl__)) vwscanf (const wchar_t * __restrict__, __gnuc_va_list);
int __attribute__((__cdecl__)) vfwscanf (FILE * __restrict__,
         const wchar_t * __restrict__, __gnuc_va_list);
int __attribute__((__cdecl__)) vswscanf (const wchar_t * __restrict__,
         const wchar_t * __restrict__, __gnuc_va_list);


#define _WSTDIO_DEFINED 





 FILE* __attribute__((__cdecl__)) wpopen (const wchar_t*, const wchar_t*);






 wint_t __attribute__((__cdecl__)) _fgetwchar (void);
 wint_t __attribute__((__cdecl__)) _fputwchar (wint_t);
 int __attribute__((__cdecl__)) _getw (FILE*);
 int __attribute__((__cdecl__)) _putw (int, FILE*);


 wint_t __attribute__((__cdecl__)) fgetwchar (void);
 wint_t __attribute__((__cdecl__)) fputwchar (wint_t);
 int __attribute__((__cdecl__)) getw (FILE*);
 int __attribute__((__cdecl__)) putw (int, FILE*);
# 15 "E:\\code\\DataBase\\/k_data.h" 2
# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 1 3
# 12 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
#define _STDLIB_H_ 





#define __need_size_t 
#define __need_wchar_t 
#define __need_NULL 

# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stddef.h" 1 3





# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 1 3 4
# 235 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_size_t
# 344 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_wchar_t
# 397 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef NULL




#define NULL ((void *)0)





#undef __need_NULL
# 7 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stddef.h" 2 3
# 23 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 2 3






#define RAND_MAX 0x7FFF




#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1
# 46 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
#define MAX_PATH (260)


#define _MAX_PATH MAX_PATH
#define _MAX_DRIVE (3)
#define _MAX_DIR 256
#define _MAX_FNAME 256
#define _MAX_EXT 256
# 72 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
extern int _argc;
extern char** _argv;




extern int* __attribute__((__cdecl__)) __p___argc(void);
extern char*** __attribute__((__cdecl__)) __p___argv(void);
extern wchar_t*** __attribute__((__cdecl__)) __p___wargv(void);

#define __argc (*__p___argc())
#define __argv (*__p___argv())
#define __wargv (*__p___wargv())
# 112 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
#define MB_CUR_MAX __mb_cur_max
   extern __attribute__ ((dllimport)) int __mb_cur_max;
# 138 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
 int* __attribute__((__cdecl__)) _errno(void);
#define errno (*_errno())

 int* __attribute__((__cdecl__)) __doserrno(void);
#define _doserrno (*__doserrno())







  extern char *** __attribute__((__cdecl__)) __p__environ(void);
  extern wchar_t *** __attribute__((__cdecl__)) __p__wenviron(void);
#define _environ (*__p__environ())
#define _wenviron (*__p__wenviron())
# 164 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
#define environ _environ
# 173 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
  extern __attribute__ ((dllimport)) int _sys_nerr;

#define sys_nerr _sys_nerr
# 197 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
extern __attribute__ ((dllimport)) char* _sys_errlist[];

#define sys_errlist _sys_errlist
# 210 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
extern unsigned __attribute__((__cdecl__)) int* __p__osver(void);
extern unsigned __attribute__((__cdecl__)) int* __p__winver(void);
extern unsigned __attribute__((__cdecl__)) int* __p__winmajor(void);
extern unsigned __attribute__((__cdecl__)) int* __p__winminor(void);







extern __attribute__ ((dllimport)) unsigned int _osver;
extern __attribute__ ((dllimport)) unsigned int _winver;
extern __attribute__ ((dllimport)) unsigned int _winmajor;
extern __attribute__ ((dllimport)) unsigned int _winminor;
# 261 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
 char** __attribute__((__cdecl__)) __p__pgmptr(void);
#define _pgmptr (*__p__pgmptr())
 wchar_t** __attribute__((__cdecl__)) __p__wpgmptr(void);
#define _wpgmptr (*__p__wpgmptr())
# 294 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
extern __attribute__ ((dllimport)) int _fmode;
# 304 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
 double __attribute__((__cdecl__)) atof (const char*);
 int __attribute__((__cdecl__)) atoi (const char*);
 long __attribute__((__cdecl__)) atol (const char*);

 int __attribute__((__cdecl__)) _wtoi (const wchar_t *);
 long __attribute__((__cdecl__)) _wtol (const wchar_t *);

 double __attribute__((__cdecl__)) strtod (const char*, char**);

extern __inline__ float __attribute__((__cdecl__)) strtof (const char *nptr, char **endptr)
  { return (strtod (nptr, endptr));}
long double __attribute__((__cdecl__)) strtold (const char * __restrict__, char ** __restrict__);


 long __attribute__((__cdecl__)) strtol (const char*, char**, int);
 unsigned long __attribute__((__cdecl__)) strtoul (const char*, char**, int);



 double __attribute__((__cdecl__)) wcstod (const wchar_t*, wchar_t**);

extern __inline__ float __attribute__((__cdecl__)) wcstof( const wchar_t *nptr, wchar_t **endptr)
{ return (wcstod(nptr, endptr)); }
long double __attribute__((__cdecl__)) wcstold (const wchar_t * __restrict__, wchar_t ** __restrict__);


 long __attribute__((__cdecl__)) wcstol (const wchar_t*, wchar_t**, int);
 unsigned long __attribute__((__cdecl__)) wcstoul (const wchar_t*, wchar_t**, int);
#define _WSTDLIB_DEFINED 


 size_t __attribute__((__cdecl__)) wcstombs (char*, const wchar_t*, size_t);
 int __attribute__((__cdecl__)) wctomb (char*, wchar_t);

 int __attribute__((__cdecl__)) mblen (const char*, size_t);
 size_t __attribute__((__cdecl__)) mbstowcs (wchar_t*, const char*, size_t);
 int __attribute__((__cdecl__)) mbtowc (wchar_t*, const char*, size_t);

 int __attribute__((__cdecl__)) rand (void);
 void __attribute__((__cdecl__)) srand (unsigned int);

 void* __attribute__((__cdecl__)) calloc (size_t, size_t) __attribute__ ((__malloc__));
 void* __attribute__((__cdecl__)) malloc (size_t) __attribute__ ((__malloc__));
 void* __attribute__((__cdecl__)) realloc (void*, size_t);
 void __attribute__((__cdecl__)) free (void*);

 void __attribute__((__cdecl__)) abort (void) __attribute__ ((__noreturn__));
 void __attribute__((__cdecl__)) exit (int) __attribute__ ((__noreturn__));


int __attribute__((__cdecl__)) atexit (void (*)(void));

 int __attribute__((__cdecl__)) system (const char*);
 char* __attribute__((__cdecl__)) getenv (const char*);


 void* __attribute__((__cdecl__)) bsearch (const void*, const void*, size_t, size_t,
     int (*)(const void*, const void*));
 void __attribute__((__cdecl__)) qsort (void*, size_t, size_t,
     int (*)(const void*, const void*));

 int __attribute__((__cdecl__)) abs (int) __attribute__ ((__const__));
 long __attribute__((__cdecl__)) labs (long) __attribute__ ((__const__));
# 376 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
typedef struct { int quot, rem; } div_t;
typedef struct { long quot, rem; } ldiv_t;

 div_t __attribute__((__cdecl__)) div (int, int) __attribute__ ((__const__));
 ldiv_t __attribute__((__cdecl__)) ldiv (long, long) __attribute__ ((__const__));







 void __attribute__((__cdecl__)) _beep (unsigned int, unsigned int);
 void __attribute__((__cdecl__)) _seterrormode (int);
 void __attribute__((__cdecl__)) _sleep (unsigned long);

 void __attribute__((__cdecl__)) _exit (int) __attribute__ ((__noreturn__));



typedef int (* _onexit_t)(void);
_onexit_t __attribute__((__cdecl__)) _onexit( _onexit_t );

 int __attribute__((__cdecl__)) _putenv (const char*);
 void __attribute__((__cdecl__)) _searchenv (const char*, const char*, char*);


 char* __attribute__((__cdecl__)) _ecvt (double, int, int*, int*);
 char* __attribute__((__cdecl__)) _fcvt (double, int, int*, int*);
 char* __attribute__((__cdecl__)) _gcvt (double, int, char*);

 void __attribute__((__cdecl__)) _makepath (char*, const char*, const char*, const char*, const char*);
 void __attribute__((__cdecl__)) _splitpath (const char*, char*, char*, char*, char*);
 char* __attribute__((__cdecl__)) _fullpath (char*, const char*, size_t);

 char* __attribute__((__cdecl__)) _itoa (int, char*, int);
 char* __attribute__((__cdecl__)) _ltoa (long, char*, int);
 char* __attribute__((__cdecl__)) _ultoa(unsigned long, char*, int);
 wchar_t* __attribute__((__cdecl__)) _itow (int, wchar_t*, int);
 wchar_t* __attribute__((__cdecl__)) _ltow (long, wchar_t*, int);
 wchar_t* __attribute__((__cdecl__)) _ultow (unsigned long, wchar_t*, int);


 long long __attribute__((__cdecl__)) _atoi64(const char *);
 char* __attribute__((__cdecl__)) _i64toa(long long, char *, int);
 char* __attribute__((__cdecl__)) _ui64toa(unsigned long long, char *, int);
 long long __attribute__((__cdecl__)) _wtoi64(const wchar_t *);
 wchar_t* __attribute__((__cdecl__)) _i64tow(long long, wchar_t *, int);
 wchar_t* __attribute__((__cdecl__)) _ui64tow(unsigned long long, wchar_t *, int);

 wchar_t* __attribute__((__cdecl__)) _wgetenv(const wchar_t*);
 int __attribute__((__cdecl__)) _wputenv(const wchar_t*);
 void __attribute__((__cdecl__)) _wsearchenv(const wchar_t*, const wchar_t*, wchar_t*);
 void __attribute__((__cdecl__)) _wmakepath(wchar_t*, const wchar_t*, const wchar_t*, const wchar_t*, const wchar_t*);
 void __attribute__((__cdecl__)) _wsplitpath (const wchar_t*, wchar_t*, wchar_t*, wchar_t*, wchar_t*);
 wchar_t* __attribute__((__cdecl__)) _wfullpath (wchar_t*, const wchar_t*, size_t);

 unsigned int __attribute__((__cdecl__)) _rotl(unsigned int, int) __attribute__ ((__const__));
 unsigned int __attribute__((__cdecl__)) _rotr(unsigned int, int) __attribute__ ((__const__));
 unsigned long __attribute__((__cdecl__)) _lrotl(unsigned long, int) __attribute__ ((__const__));
 unsigned long __attribute__((__cdecl__)) _lrotr(unsigned long, int) __attribute__ ((__const__));




 int __attribute__((__cdecl__)) putenv (const char*);
 void __attribute__((__cdecl__)) searchenv (const char*, const char*, char*);

 char* __attribute__((__cdecl__)) itoa (int, char*, int);
 char* __attribute__((__cdecl__)) ltoa (long, char*, int);


 char* __attribute__((__cdecl__)) ecvt (double, int, int*, int*);
 char* __attribute__((__cdecl__)) fcvt (double, int, int*, int*);
 char* __attribute__((__cdecl__)) gcvt (double, int, char*);
# 461 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdlib.h" 3
void __attribute__((__cdecl__)) _Exit(int) __attribute__ ((__noreturn__));

extern __inline__ void __attribute__((__cdecl__)) _Exit(int status)
 { _exit(status); }


typedef struct { long long quot, rem; } lldiv_t;

lldiv_t __attribute__((__cdecl__)) lldiv (long long, long long) __attribute__ ((__const__));

extern __inline__ long long __attribute__((__cdecl__)) llabs(long long _j)
  {return (_j >= 0 ? _j : -_j);}

long long __attribute__((__cdecl__)) strtoll (const char* __restrict__, char** __restrict, int);
unsigned long long __attribute__((__cdecl__)) strtoull (const char* __restrict__, char** __restrict__, int);


long long __attribute__((__cdecl__)) atoll (const char *);


long long __attribute__((__cdecl__)) wtoll (const wchar_t *);
char* __attribute__((__cdecl__)) lltoa (long long, char *, int);
char* __attribute__((__cdecl__)) ulltoa (unsigned long long , char *, int);
wchar_t* __attribute__((__cdecl__)) lltow (long long, wchar_t *, int);
wchar_t* __attribute__((__cdecl__)) ulltow (unsigned long long, wchar_t *, int);


extern __inline__ long long __attribute__((__cdecl__)) atoll (const char * _c)
 { return _atoi64 (_c); }
extern __inline__ char* __attribute__((__cdecl__)) lltoa (long long _n, char * _c, int _i)
 { return _i64toa (_n, _c, _i); }
extern __inline__ char* __attribute__((__cdecl__)) ulltoa (unsigned long long _n, char * _c, int _i)
 { return _ui64toa (_n, _c, _i); }
extern __inline__ long long __attribute__((__cdecl__)) wtoll (const wchar_t * _w)
  { return _wtoi64 (_w); }
extern __inline__ wchar_t* __attribute__((__cdecl__)) lltow (long long _n, wchar_t * _w, int _i)
 { return _i64tow (_n, _w, _i); }
extern __inline__ wchar_t* __attribute__((__cdecl__)) ulltow (unsigned long long _n, wchar_t * _w, int _i)
 { return _ui64tow (_n, _w, _i); }
# 16 "E:\\code\\DataBase\\/k_data.h" 2
# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 1 3
# 13 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
#define _MATH_H_ 


       
# 17 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
# 26 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
#define _DOMAIN 1
#define _SING 2
#define _OVERFLOW 3
#define _UNDERFLOW 4
#define _TLOSS 5
#define _PLOSS 6
# 40 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
#define DOMAIN _DOMAIN
#define SING _SING
#define OVERFLOW _OVERFLOW
#define UNDERFLOW _UNDERFLOW
#define TLOSS _TLOSS
#define PLOSS _PLOSS







#define M_E 2.7182818284590452354
#define M_LOG2E 1.4426950408889634074
#define M_LOG10E 0.43429448190325182765
#define M_LN2 0.69314718055994530942
#define M_LN10 2.30258509299404568402
#define M_PI 3.14159265358979323846
#define M_PI_2 1.57079632679489661923
#define M_PI_4 0.78539816339744830962
#define M_1_PI 0.31830988618379067154
#define M_2_PI 0.63661977236758134308
#define M_2_SQRTPI 1.12837916709551257390
#define M_SQRT2 1.41421356237309504880
#define M_SQRT1_2 0.70710678118654752440






#define __MINGW_FPCLASS_DEFINED 1

#define _FPCLASS_SNAN 0x0001
#define _FPCLASS_QNAN 0x0002
#define _FPCLASS_NINF 0x0004
#define _FPCLASS_NN 0x0008
#define _FPCLASS_ND 0x0010
#define _FPCLASS_NZ 0x0020
#define _FPCLASS_PZ 0x0040
#define _FPCLASS_PD 0x0080
#define _FPCLASS_PN 0x0100
#define _FPCLASS_PINF 0x0200
# 118 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
extern __attribute__ ((dllimport)) double _HUGE;
#define HUGE_VAL _HUGE
# 128 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
struct _exception
{
 int type;
 char *name;
 double arg1;
 double arg2;
 double retval;
};

 double __attribute__((__cdecl__)) sin (double);
 double __attribute__((__cdecl__)) cos (double);
 double __attribute__((__cdecl__)) tan (double);
 double __attribute__((__cdecl__)) sinh (double);
 double __attribute__((__cdecl__)) cosh (double);
 double __attribute__((__cdecl__)) tanh (double);
 double __attribute__((__cdecl__)) asin (double);
 double __attribute__((__cdecl__)) acos (double);
 double __attribute__((__cdecl__)) atan (double);
 double __attribute__((__cdecl__)) atan2 (double, double);
 double __attribute__((__cdecl__)) exp (double);
 double __attribute__((__cdecl__)) log (double);
 double __attribute__((__cdecl__)) log10 (double);
 double __attribute__((__cdecl__)) pow (double, double);
 double __attribute__((__cdecl__)) sqrt (double);
 double __attribute__((__cdecl__)) ceil (double);
 double __attribute__((__cdecl__)) floor (double);
 double __attribute__((__cdecl__)) fabs (double);
 double __attribute__((__cdecl__)) ldexp (double, int);
 double __attribute__((__cdecl__)) frexp (double, int*);
 double __attribute__((__cdecl__)) modf (double, double*);
 double __attribute__((__cdecl__)) fmod (double, double);
# 204 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
struct _complex
{
 double x;
 double y;
};

 double __attribute__((__cdecl__)) _cabs (struct _complex);

 double __attribute__((__cdecl__)) _hypot (double, double);
 double __attribute__((__cdecl__)) _j0 (double);
 double __attribute__((__cdecl__)) _j1 (double);
 double __attribute__((__cdecl__)) _jn (int, double);
 double __attribute__((__cdecl__)) _y0 (double);
 double __attribute__((__cdecl__)) _y1 (double);
 double __attribute__((__cdecl__)) _yn (int, double);
 int __attribute__((__cdecl__)) _matherr (struct _exception *);
# 228 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
 double __attribute__((__cdecl__)) _chgsign (double);
 double __attribute__((__cdecl__)) _copysign (double, double);
 double __attribute__((__cdecl__)) _logb (double);
 double __attribute__((__cdecl__)) _nextafter (double, double);
 double __attribute__((__cdecl__)) _scalb (double, long);

 int __attribute__((__cdecl__)) _finite (double);
 int __attribute__((__cdecl__)) _fpclass (double);
 int __attribute__((__cdecl__)) _isnan (double);
# 248 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
 double __attribute__((__cdecl__)) j0 (double);
 double __attribute__((__cdecl__)) j1 (double);
 double __attribute__((__cdecl__)) jn (int, double);
 double __attribute__((__cdecl__)) y0 (double);
 double __attribute__((__cdecl__)) y1 (double);
 double __attribute__((__cdecl__)) yn (int, double);

 double __attribute__((__cdecl__)) chgsign (double);
 double __attribute__((__cdecl__)) scalb (double, long);
 int __attribute__((__cdecl__)) finite (double);
 int __attribute__((__cdecl__)) fpclass (double);

#define FP_SNAN _FPCLASS_SNAN
#define FP_QNAN _FPCLASS_QNAN
#define FP_NINF _FPCLASS_NINF
#define FP_PINF _FPCLASS_PINF
#define FP_NDENORM _FPCLASS_ND
#define FP_PDENORM _FPCLASS_PD
#define FP_NZERO _FPCLASS_NZ
#define FP_PZERO _FPCLASS_PZ
#define FP_NNORM _FPCLASS_NN
#define FP_PNORM _FPCLASS_PN
# 286 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
#define NAN (0.0F/0.0F)
#define HUGE_VALF (1.0F/0.0F)
#define HUGE_VALL (1.0L/0.0L)
#define INFINITY (1.0F/0.0F)
# 299 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
#define FP_NAN 0x0100
#define FP_NORMAL 0x0400
#define FP_INFINITE (FP_NAN | FP_NORMAL)
#define FP_ZERO 0x4000
#define FP_SUBNORMAL (FP_NORMAL | FP_ZERO)
# 314 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
extern int __attribute__((__cdecl__)) __fpclassifyf (float);
extern int __attribute__((__cdecl__)) __fpclassify (double);

extern __inline__ int __attribute__((__cdecl__)) __fpclassifyl (long double x){
  unsigned short sw;
  __asm__ ("fxam; fstsw %%ax;" : "=a" (sw): "t" (x));
  return sw & (0x0100 | 0x0400 | 0x4000 );
}

#define fpclassify(x) (sizeof (x) == sizeof (float) ? __fpclassifyf (x) : sizeof (x) == sizeof (double) ? __fpclassify (x) : __fpclassifyl (x))




#define isfinite(x) ((fpclassify(x) & FP_NAN) == 0)


#define isinf(x) (fpclassify(x) == FP_INFINITE)





extern __inline__ int __attribute__((__cdecl__)) __isnan (double _x)
{
  unsigned short sw;
  __asm__ ("fxam;"
    "fstsw %%ax": "=a" (sw) : "t" (_x));
  return (sw & (0x0100 | 0x0400 | (0x0100 | 0x0400) | 0x4000 | (0x0400 | 0x4000)))
    == 0x0100;
}

extern __inline__ int __attribute__((__cdecl__)) __isnanf (float _x)
{
  unsigned short sw;
  __asm__ ("fxam;"
     "fstsw %%ax": "=a" (sw) : "t" (_x));
  return (sw & (0x0100 | 0x0400 | (0x0100 | 0x0400) | 0x4000 | (0x0400 | 0x4000)))
    == 0x0100;
}

extern __inline__ int __attribute__((__cdecl__)) __isnanl (long double _x)
{
  unsigned short sw;
  __asm__ ("fxam;"
     "fstsw %%ax": "=a" (sw) : "t" (_x));
  return (sw & (0x0100 | 0x0400 | (0x0100 | 0x0400) | 0x4000 | (0x0400 | 0x4000)))
    == 0x0100;
}


#define isnan(x) (sizeof (x) == sizeof (float) ? __isnanf (x) : sizeof (x) == sizeof (double) ? __isnan (x) : __isnanl (x))




#define isnormal(x) (fpclassify(x) == FP_NORMAL)


extern __inline__ int __attribute__((__cdecl__)) __signbit (double x) {
  unsigned short stw;
  __asm__ ( "fxam; fstsw %%ax;": "=a" (stw) : "t" (x));
  return stw & 0x0200;
}

extern __inline__ int __attribute__((__cdecl__)) __signbitf (float x) {
  unsigned short stw;
  __asm__ ("fxam; fstsw %%ax;": "=a" (stw) : "t" (x));
  return stw & 0x0200;
}

extern __inline__ int __attribute__((__cdecl__)) __signbitl (long double x) {
  unsigned short stw;
  __asm__ ("fxam; fstsw %%ax;": "=a" (stw) : "t" (x));
  return stw & 0x0200;
}

#define signbit(x) (sizeof (x) == sizeof (float) ? __signbitf (x) : sizeof (x) == sizeof (double) ? __signbit (x) : __signbitl (x))




extern float __attribute__((__cdecl__)) sinf (float);
extern long double __attribute__((__cdecl__)) sinl (long double);

extern float __attribute__((__cdecl__)) cosf (float);
extern long double __attribute__((__cdecl__)) cosl (long double);

extern float __attribute__((__cdecl__)) tanf (float);
extern long double __attribute__((__cdecl__)) tanl (long double);

extern float __attribute__((__cdecl__)) asinf (float);
extern long double __attribute__((__cdecl__)) asinl (long double);

extern float __attribute__((__cdecl__)) acosf (float);
extern long double __attribute__((__cdecl__)) acosl (long double);

extern float __attribute__((__cdecl__)) atanf (float);
extern long double __attribute__((__cdecl__)) atanl (long double);

extern float __attribute__((__cdecl__)) atan2f (float, float);
extern long double __attribute__((__cdecl__)) atan2l (long double, long double);


extern __inline__ float __attribute__((__cdecl__)) sinhf (float x)
  {return (float) sinh (x);}
extern long double __attribute__((__cdecl__)) sinhl (long double);

extern __inline__ float __attribute__((__cdecl__)) coshf (float x)
  {return (float) cosh (x);}
extern long double __attribute__((__cdecl__)) coshl (long double);

extern __inline__ float __attribute__((__cdecl__)) tanhf (float x)
  {return (float) tanh (x);}
extern long double __attribute__((__cdecl__)) tanhl (long double);



extern double __attribute__((__cdecl__)) acosh (double);
extern float __attribute__((__cdecl__)) acoshf (float);
extern long double __attribute__((__cdecl__)) acoshl (long double);


extern double __attribute__((__cdecl__)) asinh (double);
extern float __attribute__((__cdecl__)) asinhf (float);
extern long double __attribute__((__cdecl__)) asinhl (long double);


extern double __attribute__((__cdecl__)) atanh (double);
extern float __attribute__((__cdecl__)) atanf (float);
extern long double __attribute__((__cdecl__)) atanhl (long double);



extern __inline__ float __attribute__((__cdecl__)) expf (float x)
  {return (float) exp (x);}
extern long double __attribute__((__cdecl__)) expl (long double);


extern double __attribute__((__cdecl__)) exp2(double);
extern float __attribute__((__cdecl__)) exp2f(float);
extern long double __attribute__((__cdecl__)) exp2l(long double);




extern __inline__ float __attribute__((__cdecl__)) frexpf (float x, int* expn)
  {return (float) frexp (x, expn);}
extern long double __attribute__((__cdecl__)) frexpl (long double, int*);


#define FP_ILOGB0 ((int)0x80000000)
#define FP_ILOGBNAN ((int)0x80000000)
extern int __attribute__((__cdecl__)) ilogb (double);
extern int __attribute__((__cdecl__)) ilogbf (float);
extern int __attribute__((__cdecl__)) ilogbl (long double);


extern __inline__ float __attribute__((__cdecl__)) ldexpf (float x, int expn)
  {return (float) ldexp (x, expn);}
extern long double __attribute__((__cdecl__)) ldexpl (long double, int);


extern float __attribute__((__cdecl__)) logf (float);
extern long double __attribute__((__cdecl__)) logl (long double);


extern float __attribute__((__cdecl__)) log10f (float);
extern long double __attribute__((__cdecl__)) log10l (long double);


extern double __attribute__((__cdecl__)) log1p(double);
extern float __attribute__((__cdecl__)) log1pf(float);
extern long double __attribute__((__cdecl__)) log1pl(long double);


extern double __attribute__((__cdecl__)) log2 (double);
extern float __attribute__((__cdecl__)) log2f (float);
extern long double __attribute__((__cdecl__)) log2l (long double);


extern double __attribute__((__cdecl__)) logb (double);
extern float __attribute__((__cdecl__)) logbf (float);
extern long double __attribute__((__cdecl__)) logbl (long double);

extern __inline__ double __attribute__((__cdecl__)) logb (double x)
{
  double res;
  __asm__ ("fxtract\n\t"
       "fstp	%%st" : "=t" (res) : "0" (x));
  return res;
}

extern __inline__ float __attribute__((__cdecl__)) logbf (float x)
{
  float res;
  __asm__ ("fxtract\n\t"
       "fstp	%%st" : "=t" (res) : "0" (x));
  return res;
}

extern __inline__ long double __attribute__((__cdecl__)) logbl (long double x)
{
  long double res;
  __asm__ ("fxtract\n\t"
       "fstp	%%st" : "=t" (res) : "0" (x));
  return res;
}


extern float __attribute__((__cdecl__)) modff (float, float*);
extern long double __attribute__((__cdecl__)) modfl (long double, long double*);


extern double __attribute__((__cdecl__)) scalbn (double, int);
extern float __attribute__((__cdecl__)) scalbnf (float, int);
extern long double __attribute__((__cdecl__)) scalbnl (long double, int);

extern double __attribute__((__cdecl__)) scalbln (double, long);
extern float __attribute__((__cdecl__)) scalblnf (float, long);
extern long double __attribute__((__cdecl__)) scalblnl (long double, long);



extern double __attribute__((__cdecl__)) cbrt (double);
extern float __attribute__((__cdecl__)) cbrtf (float);
extern long double __attribute__((__cdecl__)) cbrtl (long double);


extern float __attribute__((__cdecl__)) fabsf (float x);
extern long double __attribute__((__cdecl__)) fabsl (long double x);


extern double __attribute__((__cdecl__)) hypot (double, double);
extern __inline__ float __attribute__((__cdecl__)) hypotf (float x, float y)
  { return (float) hypot (x, y);}
extern long double __attribute__((__cdecl__)) hypotl (long double, long double);


extern __inline__ float __attribute__((__cdecl__)) powf (float x, float y)
  {return (float) pow (x, y);}
extern long double __attribute__((__cdecl__)) powl (long double, long double);


extern float __attribute__((__cdecl__)) sqrtf (float);
extern long double __attribute__((__cdecl__)) sqrtl (long double);


extern double __attribute__((__cdecl__)) erf (double);
extern float __attribute__((__cdecl__)) erff (float);





extern double __attribute__((__cdecl__)) erfc (double);
extern float __attribute__((__cdecl__)) erfcf (float);





extern double __attribute__((__cdecl__)) lgamma (double);
extern float __attribute__((__cdecl__)) lgammaf (float);
extern long double __attribute__((__cdecl__)) lgammal (long double);


extern double __attribute__((__cdecl__)) tgamma (double);
extern float __attribute__((__cdecl__)) tgammaf (float);
extern long double __attribute__((__cdecl__)) tgammal (long double);


extern float __attribute__((__cdecl__)) ceilf (float);
extern long double __attribute__((__cdecl__)) ceill (long double);


extern float __attribute__((__cdecl__)) floorf (float);
extern long double __attribute__((__cdecl__)) floorl (long double);


extern double __attribute__((__cdecl__)) nearbyint ( double);
extern float __attribute__((__cdecl__)) nearbyintf (float);
extern long double __attribute__((__cdecl__)) nearbyintl (long double);



extern __inline__ double __attribute__((__cdecl__)) rint (double x)
{
  double retval;
  __asm__ ("frndint;": "=t" (retval) : "0" (x));
  return retval;
}

extern __inline__ float __attribute__((__cdecl__)) rintf (float x)
{
  float retval;
  __asm__ ("frndint;" : "=t" (retval) : "0" (x) );
  return retval;
}

extern __inline__ long double __attribute__((__cdecl__)) rintl (long double x)
{
  long double retval;
  __asm__ ("frndint;" : "=t" (retval) : "0" (x) );
  return retval;
}


extern __inline__ long __attribute__((__cdecl__)) lrint (double x)
{
  long retval;
  __asm__ __volatile__ ("fistpl %0" : "=m" (retval) : "t" (x) : "st"); return retval;


}

extern __inline__ long __attribute__((__cdecl__)) lrintf (float x)
{
  long retval;
  __asm__ __volatile__ ("fistpl %0" : "=m" (retval) : "t" (x) : "st"); return retval;


}

extern __inline__ long __attribute__((__cdecl__)) lrintl (long double x)
{
  long retval;
  __asm__ __volatile__ ("fistpl %0" : "=m" (retval) : "t" (x) : "st"); return retval;


}

extern __inline__ long long __attribute__((__cdecl__)) llrint (double x)
{
  long long retval;
  __asm__ __volatile__ ("fistpll %0" : "=m" (retval) : "t" (x) : "st"); return retval;


}

extern __inline__ long long __attribute__((__cdecl__)) llrintf (float x)
{
  long long retval;
  __asm__ __volatile__ ("fistpll %0" : "=m" (retval) : "t" (x) : "st"); return retval;


}

extern __inline__ long long __attribute__((__cdecl__)) llrintl (long double x)
{
  long long retval;
  __asm__ __volatile__ ("fistpll %0" : "=m" (retval) : "t" (x) : "st"); return retval;


}



extern double __attribute__((__cdecl__)) round (double);
extern float __attribute__((__cdecl__)) roundf (float);
extern long double __attribute__((__cdecl__)) roundl (long double);


extern long __attribute__((__cdecl__)) lround (double);
extern long __attribute__((__cdecl__)) lroundf (float);
extern long __attribute__((__cdecl__)) lroundl (long double);

extern long long __attribute__((__cdecl__)) llround (double);
extern long long __attribute__((__cdecl__)) llroundf (float);
extern long long __attribute__((__cdecl__)) llroundl (long double);



extern double __attribute__((__cdecl__)) trunc (double);
extern float __attribute__((__cdecl__)) truncf (float);
extern long double __attribute__((__cdecl__)) truncl (long double);


extern float __attribute__((__cdecl__)) fmodf (float, float);
extern long double __attribute__((__cdecl__)) fmodl (long double, long double);


extern double __attribute__((__cdecl__)) remainder (double, double);
extern float __attribute__((__cdecl__)) remainderf (float, float);
extern long double __attribute__((__cdecl__)) remainderl (long double, long double);


extern double __attribute__((__cdecl__)) remquo(double, double, int *);
extern float __attribute__((__cdecl__)) remquof(float, float, int *);
extern long double __attribute__((__cdecl__)) remquol(long double, long double, int *);


extern double __attribute__((__cdecl__)) copysign (double, double);
extern float __attribute__((__cdecl__)) copysignf (float, float);
extern long double __attribute__((__cdecl__)) copysignl (long double, long double);


extern double __attribute__((__cdecl__)) nan(const char *tagp);
extern float __attribute__((__cdecl__)) nanf(const char *tagp);
extern long double __attribute__((__cdecl__)) nanl(const char *tagp);


#define _nan() nan("")
#define _nanf() nanf("")
#define _nanl() nanl("")



extern double __attribute__((__cdecl__)) nextafter (double, double);
extern float __attribute__((__cdecl__)) nextafterf (float, float);







extern double __attribute__((__cdecl__)) fdim (double x, double y);
extern float __attribute__((__cdecl__)) fdimf (float x, float y);
extern long double __attribute__((__cdecl__)) fdiml (long double x, long double y);







extern double __attribute__((__cdecl__)) fmax (double, double);
extern float __attribute__((__cdecl__)) fmaxf (float, float);
extern long double __attribute__((__cdecl__)) fmaxl (long double, long double);


extern double __attribute__((__cdecl__)) fmin (double, double);
extern float __attribute__((__cdecl__)) fminf (float, float);
extern long double __attribute__((__cdecl__)) fminl (long double, long double);



extern double __attribute__((__cdecl__)) fma (double, double, double);
extern float __attribute__((__cdecl__)) fmaf (float, float, float);
extern long double __attribute__((__cdecl__)) fmal (long double, long double, long double);
# 768 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/math.h" 3
#define isgreater(x,y) __builtin_isgreater(x, y)
#define isgreaterequal(x,y) __builtin_isgreaterequal(x, y)
#define isless(x,y) __builtin_isless(x, y)
#define islessequal(x,y) __builtin_islessequal(x, y)
#define islessgreater(x,y) __builtin_islessgreater(x, y)
#define isunordered(x,y) __builtin_isunordered(x, y)
# 17 "E:\\code\\DataBase\\/k_data.h" 2
# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/float.h" 1 3
# 19 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/float.h" 3
# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/float.h" 1 3 4
# 32 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/float.h" 3 4
#define _FLOAT_H___ 


#undef FLT_RADIX
#define FLT_RADIX __FLT_RADIX__


#undef FLT_MANT_DIG
#undef DBL_MANT_DIG
#undef LDBL_MANT_DIG
#define FLT_MANT_DIG __FLT_MANT_DIG__
#define DBL_MANT_DIG __DBL_MANT_DIG__
#define LDBL_MANT_DIG __LDBL_MANT_DIG__
# 53 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/float.h" 3 4
#undef FLT_DIG
#undef DBL_DIG
#undef LDBL_DIG
#define FLT_DIG __FLT_DIG__
#define DBL_DIG __DBL_DIG__
#define LDBL_DIG __LDBL_DIG__


#undef FLT_MIN_EXP
#undef DBL_MIN_EXP
#undef LDBL_MIN_EXP
#define FLT_MIN_EXP __FLT_MIN_EXP__
#define DBL_MIN_EXP __DBL_MIN_EXP__
#define LDBL_MIN_EXP __LDBL_MIN_EXP__






#undef FLT_MIN_10_EXP
#undef DBL_MIN_10_EXP
#undef LDBL_MIN_10_EXP
#define FLT_MIN_10_EXP __FLT_MIN_10_EXP__
#define DBL_MIN_10_EXP __DBL_MIN_10_EXP__
#define LDBL_MIN_10_EXP __LDBL_MIN_10_EXP__


#undef FLT_MAX_EXP
#undef DBL_MAX_EXP
#undef LDBL_MAX_EXP
#define FLT_MAX_EXP __FLT_MAX_EXP__
#define DBL_MAX_EXP __DBL_MAX_EXP__
#define LDBL_MAX_EXP __LDBL_MAX_EXP__






#undef FLT_MAX_10_EXP
#undef DBL_MAX_10_EXP
#undef LDBL_MAX_10_EXP
#define FLT_MAX_10_EXP __FLT_MAX_10_EXP__
#define DBL_MAX_10_EXP __DBL_MAX_10_EXP__
#define LDBL_MAX_10_EXP __LDBL_MAX_10_EXP__





#undef FLT_MAX
#undef DBL_MAX
#undef LDBL_MAX
#define FLT_MAX __FLT_MAX__
#define DBL_MAX __DBL_MAX__
#define LDBL_MAX __LDBL_MAX__



#undef FLT_EPSILON
#undef DBL_EPSILON
#undef LDBL_EPSILON
#define FLT_EPSILON __FLT_EPSILON__
#define DBL_EPSILON __DBL_EPSILON__
#define LDBL_EPSILON __LDBL_EPSILON__


#undef FLT_MIN
#undef DBL_MIN
#undef LDBL_MIN
#define FLT_MIN __FLT_MIN__
#define DBL_MIN __DBL_MIN__
#define LDBL_MIN __LDBL_MIN__



#undef FLT_ROUNDS
#define FLT_ROUNDS 1
# 20 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/float.h" 2 3


#define _MINGW_FLOAT_H_ 
# 35 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/float.h" 3
#define _MCW_EM 0x0008001F
#define _MCW_IC 0x00040000
#define _MCW_RC 0x00000300
#define _MCW_PC 0x00030000


#define _EM_INVALID 0x00000010
#define _EM_DENORMAL 0x00080000
#define _EM_ZERODIVIDE 0x00000008
#define _EM_OVERFLOW 0x00000004
#define _EM_UNDERFLOW 0x00000002
#define _EM_INEXACT 0x00000001
#define _IC_AFFINE 0x00040000
#define _IC_PROJECTIVE 0x00000000
#define _RC_CHOP 0x00000300
#define _RC_UP 0x00000200
#define _RC_DOWN 0x00000100
#define _RC_NEAR 0x00000000
#define _PC_24 0x00020000
#define _PC_53 0x00010000
#define _PC_64 0x00000000
# 75 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/float.h" 3
#define _SW_UNEMULATED 0x0040
#define _SW_SQRTNEG 0x0080
#define _SW_STACKOVERFLOW 0x0200
#define _SW_STACKUNDERFLOW 0x0400


#define _FPE_INVALID 0x81
#define _FPE_DENORMAL 0x82
#define _FPE_ZERODIVIDE 0x83
#define _FPE_OVERFLOW 0x84
#define _FPE_UNDERFLOW 0x85
#define _FPE_INEXACT 0x86
#define _FPE_UNEMULATED 0x87
#define _FPE_SQRTNEG 0x88
#define _FPE_STACKOVERFLOW 0x8a
#define _FPE_STACKUNDERFLOW 0x8b
#define _FPE_EXPLICITGEN 0x8c
# 102 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/float.h" 3
 unsigned int __attribute__((__cdecl__)) _controlfp (unsigned int unNew, unsigned int unMask);
 unsigned int __attribute__((__cdecl__)) _control87 (unsigned int unNew, unsigned int unMask);


 unsigned int __attribute__((__cdecl__)) _clearfp (void);
 unsigned int __attribute__((__cdecl__)) _statusfp (void);
#define _clear87 _clearfp
#define _status87 _statusfp
# 121 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/float.h" 3
void __attribute__((__cdecl__)) _fpreset (void);
void __attribute__((__cdecl__)) fpreset (void);


 int * __attribute__((__cdecl__)) __fpecode(void);
#define _fpecode (*(__fpecode()))






 double __attribute__((__cdecl__)) _chgsign (double);
 double __attribute__((__cdecl__)) _copysign (double, double);
 double __attribute__((__cdecl__)) _logb (double);
 double __attribute__((__cdecl__)) _nextafter (double, double);
 double __attribute__((__cdecl__)) _scalb (double, long);

 int __attribute__((__cdecl__)) _finite (double);
 int __attribute__((__cdecl__)) _fpclass (double);
 int __attribute__((__cdecl__)) _isnan (double);
# 18 "E:\\code\\DataBase\\/k_data.h" 2
# 1 "E:\\code\\DataBase\\/k_error.h" 1





#define __K_ERROR_H__ 



# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdarg.h" 1 3





# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stdarg.h" 1 3 4
# 35 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stdarg.h" 3 4
#define _STDARG_H 
#define _ANSI_STDARG_H_ 

#undef __need___va_list
# 51 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stdarg.h" 3 4
#define va_start(v,l) __builtin_va_start(v,l)
#define va_end(v) __builtin_va_end(v)
#define va_arg(v,l) __builtin_va_arg(v,l)

#define va_copy(d,s) __builtin_va_copy(d,s)

#define __va_copy(d,s) __builtin_va_copy(d,s)
# 106 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stdarg.h" 3 4
typedef __gnuc_va_list va_list;





#define _VA_LIST_ 


#define _VA_LIST 


#define _VA_LIST_DEFINED 


#define _VA_LIST_T_H 


#define __va_list__ 
# 7 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdarg.h" 2 3
# 11 "E:\\code\\DataBase\\/k_error.h" 2
# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/string.h" 1 3
# 12 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/string.h" 3
#define _STRING_H_ 







#define __need_size_t 
#define __need_wchar_t 
#define __need_NULL 

# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stddef.h" 1 3





# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 1 3 4
# 235 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_size_t
# 344 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_wchar_t
# 397 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef NULL




#define NULL ((void *)0)





#undef __need_NULL
# 7 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stddef.h" 2 3
# 25 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/string.h" 2 3
# 36 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/string.h" 3
 void* __attribute__((__cdecl__)) memchr (const void*, int, size_t) __attribute__ ((__pure__));
 int __attribute__((__cdecl__)) memcmp (const void*, const void*, size_t) __attribute__ ((__pure__));
 void* __attribute__((__cdecl__)) memcpy (void*, const void*, size_t);
 void* __attribute__((__cdecl__)) memmove (void*, const void*, size_t);
 void* __attribute__((__cdecl__)) memset (void*, int, size_t);
 char* __attribute__((__cdecl__)) strcat (char*, const char*);
 char* __attribute__((__cdecl__)) strchr (const char*, int) __attribute__ ((__pure__));
 int __attribute__((__cdecl__)) strcmp (const char*, const char*) __attribute__ ((__pure__));
 int __attribute__((__cdecl__)) strcoll (const char*, const char*);
 char* __attribute__((__cdecl__)) strcpy (char*, const char*);
 size_t __attribute__((__cdecl__)) strcspn (const char*, const char*) __attribute__ ((__pure__));
 char* __attribute__((__cdecl__)) strerror (int);

 size_t __attribute__((__cdecl__)) strlen (const char*) __attribute__ ((__pure__));
 char* __attribute__((__cdecl__)) strncat (char*, const char*, size_t);
 int __attribute__((__cdecl__)) strncmp (const char*, const char*, size_t) __attribute__ ((__pure__));
 char* __attribute__((__cdecl__)) strncpy (char*, const char*, size_t);
 char* __attribute__((__cdecl__)) strpbrk (const char*, const char*) __attribute__ ((__pure__));
 char* __attribute__((__cdecl__)) strrchr (const char*, int) __attribute__ ((__pure__));
 size_t __attribute__((__cdecl__)) strspn (const char*, const char*) __attribute__ ((__pure__));
 char* __attribute__((__cdecl__)) strstr (const char*, const char*) __attribute__ ((__pure__));
 char* __attribute__((__cdecl__)) strtok (char*, const char*);
 size_t __attribute__((__cdecl__)) strxfrm (char*, const char*, size_t);





 char* __attribute__((__cdecl__)) _strerror (const char *);
 void* __attribute__((__cdecl__)) _memccpy (void*, const void*, int, size_t);
 int __attribute__((__cdecl__)) _memicmp (const void*, const void*, size_t);
 char* __attribute__((__cdecl__)) _strdup (const char*) __attribute__ ((__malloc__));
 int __attribute__((__cdecl__)) _strcmpi (const char*, const char*);
 int __attribute__((__cdecl__)) _stricmp (const char*, const char*);
 int __attribute__((__cdecl__)) _stricoll (const char*, const char*);
 char* __attribute__((__cdecl__)) _strlwr (char*);
 int __attribute__((__cdecl__)) _strnicmp (const char*, const char*, size_t);
 char* __attribute__((__cdecl__)) _strnset (char*, int, size_t);
 char* __attribute__((__cdecl__)) _strrev (char*);
 char* __attribute__((__cdecl__)) _strset (char*, int);
 char* __attribute__((__cdecl__)) _strupr (char*);
 void __attribute__((__cdecl__)) _swab (const char*, char*, size_t);


 int __attribute__((__cdecl__)) _strncoll(const char*, const char*, size_t);
 int __attribute__((__cdecl__)) _strnicoll(const char*, const char*, size_t);
# 90 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/string.h" 3
 void* __attribute__((__cdecl__)) memccpy (void*, const void*, int, size_t);
 int __attribute__((__cdecl__)) memicmp (const void*, const void*, size_t);
 char* __attribute__((__cdecl__)) strdup (const char*) __attribute__ ((__malloc__));
 int __attribute__((__cdecl__)) strcmpi (const char*, const char*);
 int __attribute__((__cdecl__)) stricmp (const char*, const char*);
extern __inline__ int __attribute__((__cdecl__))
strcasecmp (const char * __sz1, const char * __sz2)
  {return _stricmp (__sz1, __sz2);}
 int __attribute__((__cdecl__)) stricoll (const char*, const char*);
 char* __attribute__((__cdecl__)) strlwr (char*);
 int __attribute__((__cdecl__)) strnicmp (const char*, const char*, size_t);
extern __inline__ int __attribute__((__cdecl__))
strncasecmp (const char * __sz1, const char * __sz2, size_t __sizeMaxCompare)
  {return _strnicmp (__sz1, __sz2, __sizeMaxCompare);}
 char* __attribute__((__cdecl__)) strnset (char*, int, size_t);
 char* __attribute__((__cdecl__)) strrev (char*);
 char* __attribute__((__cdecl__)) strset (char*, int);
 char* __attribute__((__cdecl__)) strupr (char*);

 void __attribute__((__cdecl__)) swab (const char*, char*, size_t);
# 120 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/string.h" 3
 wchar_t* __attribute__((__cdecl__)) wcscat (wchar_t*, const wchar_t*);
 wchar_t* __attribute__((__cdecl__)) wcschr (const wchar_t*, wchar_t);
 int __attribute__((__cdecl__)) wcscmp (const wchar_t*, const wchar_t*);
 int __attribute__((__cdecl__)) wcscoll (const wchar_t*, const wchar_t*);
 wchar_t* __attribute__((__cdecl__)) wcscpy (wchar_t*, const wchar_t*);
 size_t __attribute__((__cdecl__)) wcscspn (const wchar_t*, const wchar_t*);

 size_t __attribute__((__cdecl__)) wcslen (const wchar_t*);
 wchar_t* __attribute__((__cdecl__)) wcsncat (wchar_t*, const wchar_t*, size_t);
 int __attribute__((__cdecl__)) wcsncmp(const wchar_t*, const wchar_t*, size_t);
 wchar_t* __attribute__((__cdecl__)) wcsncpy(wchar_t*, const wchar_t*, size_t);
 wchar_t* __attribute__((__cdecl__)) wcspbrk(const wchar_t*, const wchar_t*);
 wchar_t* __attribute__((__cdecl__)) wcsrchr(const wchar_t*, wchar_t);
 size_t __attribute__((__cdecl__)) wcsspn(const wchar_t*, const wchar_t*);
 wchar_t* __attribute__((__cdecl__)) wcsstr(const wchar_t*, const wchar_t*);
 wchar_t* __attribute__((__cdecl__)) wcstok(wchar_t*, const wchar_t*);
 size_t __attribute__((__cdecl__)) wcsxfrm(wchar_t*, const wchar_t*, size_t);







#define _wcscmpi _wcsicmp

 wchar_t* __attribute__((__cdecl__)) _wcsdup (const wchar_t*);
 int __attribute__((__cdecl__)) _wcsicmp (const wchar_t*, const wchar_t*);
 int __attribute__((__cdecl__)) _wcsicoll (const wchar_t*, const wchar_t*);
 wchar_t* __attribute__((__cdecl__)) _wcslwr (wchar_t*);
 int __attribute__((__cdecl__)) _wcsnicmp (const wchar_t*, const wchar_t*, size_t);
 wchar_t* __attribute__((__cdecl__)) _wcsnset (wchar_t*, wchar_t, size_t);
 wchar_t* __attribute__((__cdecl__)) _wcsrev (wchar_t*);
 wchar_t* __attribute__((__cdecl__)) _wcsset (wchar_t*, wchar_t);
 wchar_t* __attribute__((__cdecl__)) _wcsupr (wchar_t*);


 int __attribute__((__cdecl__)) _wcsncoll(const wchar_t*, const wchar_t*, size_t);
 int __attribute__((__cdecl__)) _wcsnicoll(const wchar_t*, const wchar_t*, size_t);
# 167 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/string.h" 3
int __attribute__((__cdecl__)) wcscmpi (const wchar_t * __ws1, const wchar_t * __ws2);
extern __inline__ int __attribute__((__cdecl__))
wcscmpi (const wchar_t * __ws1, const wchar_t * __ws2)
  {return _wcsicmp (__ws1, __ws2);}
 wchar_t* __attribute__((__cdecl__)) wcsdup (const wchar_t*);
 int __attribute__((__cdecl__)) wcsicmp (const wchar_t*, const wchar_t*);
 int __attribute__((__cdecl__)) wcsicoll (const wchar_t*, const wchar_t*);
 wchar_t* __attribute__((__cdecl__)) wcslwr (wchar_t*);
 int __attribute__((__cdecl__)) wcsnicmp (const wchar_t*, const wchar_t*, size_t);
 wchar_t* __attribute__((__cdecl__)) wcsnset (wchar_t*, wchar_t, size_t);
 wchar_t* __attribute__((__cdecl__)) wcsrev (wchar_t*);
 wchar_t* __attribute__((__cdecl__)) wcsset (wchar_t*, wchar_t);
 wchar_t* __attribute__((__cdecl__)) wcsupr (wchar_t*);




#define _WSTRING_DEFINED 
# 12 "E:\\code\\DataBase\\/k_error.h" 2

#define ERROR_log "error_log.txt"
#define IF_print 1
#define IF_log 2
#define IF_pause 4
#define IF_return 8
#define IF_exit 16
#define MODE_WARING IF_log
#define MODE_ERROR (IF_print | IF_log | IF_pause | IF_return)

FILE *fp_error;

int my_error(FILE *fp, int mode, const char *fmt, ...);


int my_error(FILE *fp, int mode, const char *fmt, ...)
{
     char buf_1[2048];
     char buf_2[2048];
     buf_1[0] = buf_2[0] = '\0';
     va_list args;
     __builtin_va_start(args,fmt);
     vsprintf(buf_2, fmt, args);
     strcat(buf_1, "\n---------------------------------------------- error_start ---\n");
     strcat(buf_1, buf_2);
     strcat(buf_1, "\n---------------------------------------------- error_end   ---\n");
     if((mode & 1) != 0)
         printf(buf_1);
     if((mode & 2) != 0){
         if(fp == ((void *)0)){
             fp_error = fopen("error_log.txt", "w");
             fprintf(fp_error, buf_1);
             fflush(fp_error);
         }else{
             fprintf(fp, buf_1);
             fflush(fp);
         }
     }
     if((mode & 4) != 0){
         ;
     }
     if((mode & 8) != 0 && (mode & 16) == 0)
         return -1;
     if((mode & 16) != 0)
         exit(-1);
     return 0;
}
# 19 "E:\\code\\DataBase\\/k_data.h" 2
# 1 "E:\\code\\DataBase\\/k_base.h" 1
# 12 "E:\\code\\DataBase\\/k_base.h"
# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdint.h" 1 3
# 21 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdint.h" 3
#define _STDINT_H 
#define __need_wint_t 
#define __need_wchar_t 
# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stddef.h" 1 3





# 1 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 1 3 4
# 344 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_wchar_t
# 356 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_wint_t
# 408 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/include/stddef.h" 3 4
#undef __need_NULL
# 7 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stddef.h" 2 3
# 25 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdint.h" 2 3


typedef signed char int8_t;
typedef unsigned char uint8_t;
typedef short int16_t;
typedef unsigned short uint16_t;
typedef int int32_t;
typedef unsigned uint32_t;
typedef long long int64_t;
typedef unsigned long long uint64_t;


typedef signed char int_least8_t;
typedef unsigned char uint_least8_t;
typedef short int_least16_t;
typedef unsigned short uint_least16_t;
typedef int int_least32_t;
typedef unsigned uint_least32_t;
typedef long long int_least64_t;
typedef unsigned long long uint_least64_t;





typedef char int_fast8_t;
typedef unsigned char uint_fast8_t;
typedef short int_fast16_t;
typedef unsigned short uint_fast16_t;
typedef int int_fast32_t;
typedef unsigned int uint_fast32_t;
typedef long long int_fast64_t;
typedef unsigned long long uint_fast64_t;


typedef int intptr_t;
typedef unsigned uintptr_t;


typedef long long intmax_t;
typedef unsigned long long uintmax_t;





#define INT8_MIN (-128)
#define INT16_MIN (-32768)
#define INT32_MIN (-2147483647 - 1)
#define INT64_MIN (-9223372036854775807LL - 1)

#define INT8_MAX 127
#define INT16_MAX 32767
#define INT32_MAX 2147483647
#define INT64_MAX 9223372036854775807LL

#define UINT8_MAX 0xff
#define UINT16_MAX 0xffff
#define UINT32_MAX 0xffffffff
#define UINT64_MAX 0xffffffffffffffffULL


#define INT_LEAST8_MIN INT8_MIN
#define INT_LEAST16_MIN INT16_MIN
#define INT_LEAST32_MIN INT32_MIN
#define INT_LEAST64_MIN INT64_MIN

#define INT_LEAST8_MAX INT8_MAX
#define INT_LEAST16_MAX INT16_MAX
#define INT_LEAST32_MAX INT32_MAX
#define INT_LEAST64_MAX INT64_MAX

#define UINT_LEAST8_MAX UINT8_MAX
#define UINT_LEAST16_MAX UINT16_MAX
#define UINT_LEAST32_MAX UINT32_MAX
#define UINT_LEAST64_MAX UINT64_MAX


#define INT_FAST8_MIN INT8_MIN
#define INT_FAST16_MIN INT16_MIN
#define INT_FAST32_MIN INT32_MIN
#define INT_FAST64_MIN INT64_MIN

#define INT_FAST8_MAX INT8_MAX
#define INT_FAST16_MAX INT16_MAX
#define INT_FAST32_MAX INT32_MAX
#define INT_FAST64_MAX INT64_MAX

#define UINT_FAST8_MAX UINT8_MAX
#define UINT_FAST16_MAX UINT16_MAX
#define UINT_FAST32_MAX UINT32_MAX
#define UINT_FAST64_MAX UINT64_MAX



#define INTPTR_MIN INT32_MIN
#define INTPTR_MAX INT32_MAX
#define UINTPTR_MAX UINT32_MAX


#define INTMAX_MIN INT64_MIN
#define INTMAX_MAX INT64_MAX
#define UINTMAX_MAX UINT64_MAX


#define PTRDIFF_MIN INT32_MIN
#define PTRDIFF_MAX INT32_MAX

#define SIG_ATOMIC_MIN INT32_MIN
#define SIG_ATOMIC_MAX INT32_MAX

#define SIZE_MAX UINT32_MAX


#define WCHAR_MIN 0
#define WCHAR_MAX ((wchar_t)-1)





#define WINT_MIN 0
#define WINT_MAX ((wint_t)-1)
# 168 "C:/Program Files (x86)/DEV-CPP/Bin/../lib/gcc/mingw32/3.4.2/../../../../include/stdint.h" 3
#define INT8_C(val) ((int8_t) + (val))
#define UINT8_C(val) ((uint8_t) + (val ##U))
#define INT16_C(val) ((int16_t) + (val))
#define UINT16_C(val) ((uint16_t) + (val ##U))

#define INT32_C(val) val ##L
#define UINT32_C(val) val ##UL
#define INT64_C(val) val ##LL
#define UINT64_C(val) val ##ULL


#define INTMAX_C(val) INT64_C(val)
#define UINTMAX_C(val) UINT64_C(val)
# 13 "E:\\code\\DataBase\\/k_base.h" 2


#define __K_BASE_H__ 



#define JPEG_SUPPORT_NO 
# 30 "E:\\code\\DataBase\\/k_base.h"
#define DATA_TYPE_REDEFINE_SUPPORT 
#define LITTILE_ENDIAN_SUPPORT 
# 44 "E:\\code\\DataBase\\/k_base.h"
    typedef int16_t iINT16;
    typedef uint16_t iUINT16;

    typedef int32_t iINT32;
    typedef uint32_t iUINT32;

    typedef int64_t iINT64;
    typedef uint64_t iUINT64;

    typedef int8_t iINT8;
    typedef uint8_t iUINT8;


    typedef float iFLOAT32;
    typedef double iFLOAT64;



#define iFALSE 0



#define iTRUE 1



#define iUNKNOWN 2





#define K_CMP_BIGGER 1
#define K_CMP_EQUAL 0
#define K_CMP_SMALLER -1
#define K_CMP_UNKNOWN -2

struct point{
    int x;
    int y;
};

struct Rect{
    struct point p0;
    struct point p1;
};

struct k_pair{
    void *key;
    void *value;
};
# 20 "E:\\code\\DataBase\\/k_data.h" 2

#define KDATA_MAGIC 0x940425


#define KDATA_TYPE_NONE 0
#define KDATA_TYPE_STRING 1
#define KDATA_TYPE_CHAR 2
#define KDATA_TYPE_UCHAR 3
#define KDATA_TYPE_INT32 4
#define KDATA_TYPE_UINT32 5
#define KDATA_TYPE_INT64 6
#define KDATA_TYPE_UINT64 7
#define KDATA_TYPE_FLOAT32 8
#define KDATA_TYPE_FLOAT64 9
#define KDATA_TYPE_KDATA 10



#define KDATA_P_STRING(x) ( (iINT8 **)(x) )
#define KDATA_P_CHAR(x) ( (iINT8 *)(x) )
#define KDATA_P_INT32(x) ( (iINT32 *)(x) )
#define KDATA_P_INT64(x) ( (iINT64 *)(x) )
#define KDATA_P_FLOAT32(x) ( (iFLOAT32 *)(x) )
#define KDATA_P_FLOAT64(x) ( (iFLOAT64 *)(x) )

#define KDATA_P_KDATA(d) ( (d)->type == KDATA_TYPE_STRING ? KDATA_P_STRING(((d)->p_data)) : ( (d)->type == KDATA_TYPE_CHAR ? KDATA_P_CHAR((d)->p_data) : ( (d)->type == KDATA_TYPE_INT32 ? KDATA_P_INT32((d)->p_data) : ( (d)->type == KDATA_TYPE_INT64 ? KDATA_P_INT64((d)->p_data) : ( (d)->type == KDATA_TYPE_FLOAT32 ? KDATA_P_FLOAT32((d)->p_data) : ( (d)->type == KDATA_TYPE_FLOAT64 ? KDATA_P_FLOAT64((d)->p_data) : ( NULL )))))) )
# 54 "E:\\code\\DataBase\\/k_data.h"
struct k_data{
    int magic;
 void *p_data;
 int type;
};


int k_data_malloc(struct k_data **d, void *p_data, int type);

struct k_data *k_data_just_malloc(void *p_data, int type);

int k_data_free(struct k_data *d);

int k_data_copy(struct k_data **dest, struct k_data *src);

int k_data_comp(struct k_data *data_a, struct k_data *data_b);

int k_data_comp_string(struct k_data *data_a, struct k_data *data_b);

int k_data_comp_int32(struct k_data *data_a, struct k_data *data_b);

int k_data_comp_int64(struct k_data *data_a, struct k_data *data_b);

int k_data_comp_float64(struct k_data *data_a, struct k_data *data_b);

char *k_data_convert_to_string_malloc(struct k_data *data);


struct {
    int type;
    int (*k_data_comp)(struct k_data *a, struct k_data *b);
} k_data_cmp_func[10 + 1] = {

    0 , ((void *)0),
    1 , k_data_comp_string,
    2 , ((void *)0),
    3 , ((void *)0),
    4 , k_data_comp_int32,


    5 , ((void *)0),
    6 , k_data_comp_int64,
    7 , ((void *)0),
    8 , ((void *)0),
    9 , k_data_comp_float64,
    10 , k_data_comp,
};





int k_data_malloc(struct k_data **d, void *p_data, int type)
{
    struct k_data *data;
    int length;

    if(d == ((void *)0)){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : some pointer is NULL!", __FUNCTION__);
        return -1;
    }

    *d = (struct k_data *)malloc(sizeof(struct k_data));
    data = *d;

    data -> type = type;
    data -> magic = 0x940425;

    length = k_data_sizeof_data(type, p_data);
    data -> p_data = (void *)malloc(length);
    memcpy(data -> p_data, p_data, length);

    return 0;
}


struct k_data *k_data_just_malloc(void *p_data, int type)
{
    struct k_data *data;

    k_data_malloc(&data, p_data, type);

    return data;
}


int k_data_free(struct k_data *data)
{
    if(data == ((void *)0)){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : data point to NULL!", __FUNCTION__);
        return -1;
    }
    if(data -> magic != 0x940425){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : magic number can't suit !", __FUNCTION__);
        return -1;
    }

    free(data -> p_data);
    free(data);

    return 0;
}



int k_data_sizeof_data(int type, void *data)
{
    switch(type){
        case 1:
            return strlen((char *)data) + 1;
        case 2: case 3:
            return sizeof(char);
        case 4: case 5:
            return sizeof(iINT32);
        case 6: case 7:
            return sizeof(iINT64);
        case 9:
            return sizeof(iFLOAT64);
    }

    return -1;
}


int k_data_copy(struct k_data **dest, struct k_data *src)
{
    if(src == ((void *)0)){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : some pointer is NULL!", __FUNCTION__);
        return -1;
    }
    if(src -> magic != 0x940425){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : magic number can't suit !", __FUNCTION__);
        return -1;
    }
    k_data_malloc(dest, src -> p_data, src -> type);

    return 0;
}


int k_data_comp(struct k_data *a, struct k_data *b)
{
    int type;
    int (*compare_func)(struct k_data *a, struct k_data *b);

 if(a == ((void *)0) || b == ((void *)0)){
     my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : a or b point to NULL!", __FUNCTION__);
     return -2;
 }
    if(b -> type != a -> type){
     my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : try to compare diff type!", __FUNCTION__);
        return -2;
    }

    type = a -> type;
    if(k_data_cmp_func[type].type != type){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : please check the array: k_data_cmp_func[] !", __FUNCTION__);
        return -2;
    }
    compare_func = k_data_cmp_func[type].k_data_comp;
    if(compare_func == ((void *)0)){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : unsupport compare data type!", __FUNCTION__);
        return -2;
    }else{
        return compare_func(a, b);
    }


    return -2;
}


int k_data_comp_string(struct k_data *data_a, struct k_data *data_b)
{
    int i;
    unsigned char *string_a, *string_b;

    if(data_a -> magic != 0x940425 || data_b -> magic != 0x940425){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : magic number can't suit !", __FUNCTION__);
        return -1;
    }

    string_a = (unsigned char *)data_a -> p_data;
    string_b = (unsigned char *)data_b -> p_data;

    if(string_a == ((void *)0) || string_a == ((void *)0)){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : a or b point to NULL!", __FUNCTION__);
        return -2;
 }

    for(i = 0; string_a[i] != '\0'; i ++){
        if(string_a[i] != string_b[i])
            break;
    }

    if(string_a[i] == '\0' && string_b[i] != '\0')
        return -1;
    else if(string_a[i] - string_b[i] == 0)
        return 0;
    else
        return string_a[i] - string_b[i] > 0 ? 1 : -1;
}


int k_data_comp_int32(struct k_data *data_a, struct k_data *data_b)
{
    iINT32 a, b;

    if(data_a -> magic != 0x940425 || data_b -> magic != 0x940425){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : magic number can't suit !", __FUNCTION__);
        return -1;
    }

    a = *(iINT32 *)data_a -> p_data;
    b = *(iINT32 *)data_b -> p_data;

    if(a == b){
  return 0;
 }else if(a > b){
  return 1;
    }else{
  return -1;
    }
}


int k_data_comp_int64(struct k_data *data_a, struct k_data *data_b)
{
    iINT64 a, b;

    if(data_a -> magic != 0x940425 || data_b -> magic != 0x940425){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : magic number can't suit !", __FUNCTION__);
        return -1;
    }

    a = *(iINT64 *)data_a -> p_data;
    b = *(iINT64 *)data_b -> p_data;

    if(a == b){
  return 0;
 }else if(a > b){
  return 1;
    }else{
  return -1;
    }
}


int k_data_comp_float64(struct k_data *data_a, struct k_data *data_b)
{
    iFLOAT64 a, b;

    if(data_a -> magic != 0x940425 || data_b -> magic != 0x940425){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : magic number can't suit !", __FUNCTION__);
        return -1;
    }

    a = *(iFLOAT64 *)data_a -> p_data;
    b = *(iFLOAT64 *)data_b -> p_data;

    if(fabs(a - b) < 2.2250738585072014e-308 * 10){
  return 0;
 }else if(a > b){
  return 1;
    }else{
  return -1;
    }
}


char *k_data_convert_to_string_malloc(struct k_data *data)
{
    char *str;
    int length;

    if(data == ((void *)0)){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : data point to NULL!", __FUNCTION__);
        return ((void *)0);
    }
    if(data -> magic != 0x940425){
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : magic number can't suit !", __FUNCTION__);
        return ((void *)0);
    }

    if(data -> type == 1){
        if(data -> p_data == ((void *)0)){
            my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : string point to NULL!", __FUNCTION__);
            return ((void *)0);
        }else{
            length = strlen((char *)data -> p_data);
            str = (char *)malloc(length + 1);
            memcpy(str, data -> p_data, length);
            str[length] = '\0';
        }
    }else if(data -> type == 4){
        str = (char *)malloc(128);
        sprintf(str, "%d", *(iINT32 *)data -> p_data);
        return str;
    }else if(data -> type == 6){
        str = (char *)malloc(128);


        sprintf(str, "%ld", *(iINT64 *)data -> p_data);
        return str;
    }else if(data -> type == 8){
        str = (char *)malloc(128);
        sprintf(str, "%g", *(iFLOAT32 *)data -> p_data);
        return str;
    }else if(data -> type == 9){
        str = (char *)malloc(128);
        sprintf(str, "%g", *(iFLOAT64 *)data -> p_data);
        return str;
    }else if(data -> type == 10){
        return k_data_convert_to_string_malloc(data -> p_data);
    }else{
        my_error(fp_error, (1 | 2 | 4 | 8), "<%s> : unknown data_type: %d!", __FUNCTION__, data -> type);
        return ((void *)0);
    }

    return str;
}
# 2 "E:\\code\\DataBase\\k_data.c" 2

int main()
{
    char *s1 = "hehe", *s2 = "heihei", *s3 = "GG";
    int int_4 = 123;
 struct k_data *d1, *d2, *d3, *d4;
 char *str;

    k_data_malloc(&d1, s1, 1);
    k_data_malloc(&d2, s2, 1);
    k_data_malloc(&d3, s3, 1);
    k_data_malloc(&d4, &int_4, 4);

    str = k_data_convert_to_string_malloc(d1);
    printf("data = %s\n", str);
    str = k_data_convert_to_string_malloc(d2);
    printf("data = %s\n", str);
    str = k_data_convert_to_string_malloc(d3);
    printf("data = %s\n", str);
    ( (d4)->type == 1 ? ( (iINT8 **)(((d4)->p_data)) ) : ( (d4)->type == 2 ? ( (iINT8 *)((d4)->p_data) ) : ( (d4)->type == 4 ? ( (iINT32 *)((d4)->p_data) ) : ( (d4)->type == 6 ? ( (iINT64 *)((d4)->p_data) ) : ( (d4)->type == 8 ? ( (iFLOAT32 *)((d4)->p_data) ) : ( (d4)->type == 9 ? ( (iFLOAT64 *)((d4)->p_data) ) : ( ((void *)0) )))))) );

    system("pause");
}
